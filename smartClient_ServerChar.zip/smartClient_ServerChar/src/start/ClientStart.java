package start;

import Client_Server.Client;

public class ClientStart {
	public static void main(String[] args) {
		Client client = new Client();
		client.start();
	}
}
