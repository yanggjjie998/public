package start;

import Client_Server.Server;

public class ServerStart {
	public static void main(String[] args) {
		Server server = new Server();
		server.start();
	}
}
